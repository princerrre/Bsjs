
const apiURL = '/api/auth';

async function login() {
  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;

  const response = await fetch(`${apiURL}/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password })
  });

  const data = await response.json();
  if (response.ok) {
    alert(`Welcome, ${data.username}`);
    localStorage.setItem('token', data.token);
    window.location.href = '/home.html';
  } else {
    alert(data.msg);
  }
}

function showRegister() {
  document.getElementById('content').innerHTML = \`
    <h2>Register</h2>
    <input type="text" id="regUsername" placeholder="Username" required><br><br>
    <input type="password" id="regPassword" placeholder="Password" required><br><br>
    <button onclick="register()">Register</button>
    <p>Already have an account? <a href="/" onclick="location.reload()">Login</a></p>
  \`;
}

async function register() {
  const username = document.getElementById('regUsername').value;
  const password = document.getElementById('regPassword').value;

  const response = await fetch(`${apiURL}/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password })
  });

  const data = await response.json();
  if (response.ok) {
    alert(data.msg);
    location.reload();
  } else {
    alert(data.msg);
  }
}
